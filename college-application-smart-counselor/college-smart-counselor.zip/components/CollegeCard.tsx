"use client";

import { College } from "@/types/college";
import { useApp } from "@/lib/AppContext";

interface CollegeCardProps {
  college: College;
  onClick?: () => void;
}

export default function CollegeCard({ college, onClick }: CollegeCardProps) {
  const { isSaved, addSavedCollege, removeSavedCollege } = useApp();
  const saved = isSaved(college.id);

  const handleSaveToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (saved) {
      removeSavedCollege(college.id);
    } else {
      addSavedCollege(college);
    }
  };

  const getBadgeClass = (category?: string) => {
    switch (category) {
      case "Safety":
        return "badge-safety";
      case "Target":
        return "badge-target";
      case "Reach":
        return "badge-reach";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  const safe = (v: any, fmt?: (x: any) => string) => {
    if (v === undefined || v === null || Number.isNaN(v)) return "N/A";
    return fmt ? fmt(v) : String(v);
  };

  return (
    <div onClick={onClick} className="card-hover card card-min cursor-pointer relative" style={{ overflow: "hidden" }}>
      {/* Save Button */}
      <button
        onClick={handleSaveToggle}
        aria-pressed={saved}
        title={saved ? 'Remove from saved' : 'Save college'}
        className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white border-2 border-gray-100 flex items-center justify-center hover:border-[rgba(217,119,87,0.9)] hover:text-terracotta transition-all z-20"
      >
        <svg
          className="w-5 h-5"
          fill={saved ? "currentColor" : "none"}
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"
          />
        </svg>
      </button>

      {/* College Info */}
      <div className="space-y-4">
        <div>
          <h3 className="font-display text-2xl font-bold text-charcoal mb-1 truncate">{safe(college.name)}</h3>
          <p className="text-sm text-muted">{safe(college.location)}</p>
        </div>

        {/* Category Badge */}
        {college.category && (
          <div>
            <span className={`badge ${getBadgeClass(college.category)}`}>
              {college.category}
            </span>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-100">
          <div>
            <p className="text-xs text-muted mb-1">Acceptance Rate</p>
            <p className="font-semibold text-charcoal">{safe(college.acceptanceRate, (n:any) => Number(n).toFixed(1) + '%')}</p>
          </div>
          <div>
            <p className="text-xs text-muted mb-1">Avg Cost</p>
            <p className="font-semibold text-charcoal">{college.avgCost ? '$' + (college.avgCost / 1000).toFixed(0) + 'k' : 'N/A'}</p>
          </div>
          {college.admissionProbability !== undefined && (
            <div>
              <p className="text-xs text-muted mb-1">Admission Chance</p>
              <p className="font-semibold text-sage">{Number(college.admissionProbability).toFixed(0)}%</p>
            </div>
          )}
          {college.alignmentScore !== undefined && (
            <div>
              <p className="text-xs text-muted mb-1">Match Score</p>
              <p className="font-semibold text-terracotta">{Number(college.alignmentScore).toFixed(0)}%</p>
            </div>
          )}
        </div>

        {/* Majors */}
        <div className="pt-2">
          <p className="text-xs text-muted mb-2">Popular Majors</p>
          <div className="flex flex-wrap gap-1.5">
            {(college.majors || []).slice(0, 3).map((major, idx) => (
              <span key={idx} className="px-2.5 py-1.5 text-xs bg-gray-100 text-gray-700 rounded-full">{major}</span>
            ))}
            {(college.majors || []).length > 3 && (
              <span className="px-2.5 py-1.5 text-xs text-muted">+{college.majors.length - 3} more</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}