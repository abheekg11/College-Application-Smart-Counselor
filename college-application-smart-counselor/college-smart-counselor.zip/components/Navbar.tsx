"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useApp } from "@/lib/AppContext";
import { useState } from "react";

export default function Navbar() {
  const pathname = usePathname();
  const { profile, savedColleges } = useApp();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/colleges", label: "Colleges" },
    { href: "/dashboard", label: "Dashboard" },
    { href: "/tracker", label: "Tracker" },
    { href: "/project", label: "Project" },
    { href: "/saved-colleges", label: "My Colleges" },
  ];

  const isActive = (href: string) => pathname === href;

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 flex-shrink-0">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-sage to-terracotta flex items-center justify-center text-white font-bold text-sm">
              CP
            </div>
            <div className="hidden sm:flex flex-col">
              <span className="text-lg font-bold text-charcoal leading-none">CollegePath</span>
              <span className="text-xs text-muted">College Applications</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6 flex-1 ml-8">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`text-sm font-medium transition-colors border-b-2 ${
                  isActive(link.href)
                    ? 'text-sage border-sage'
                    : 'text-charcoal border-transparent hover:text-sage'
                }`}
              >
                {link.label}
                {link.label === "My Colleges" && savedColleges.length > 0 && (
                  <span className="ml-2 inline-flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-terracotta rounded-full">
                    {savedColleges.length}
                  </span>
                )}
              </Link>
            ))}
          </div>

          {/* Right Section - Desktop */}
          <div className="hidden md:flex items-center gap-4">
            {profile ? (
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-sm font-semibold text-charcoal">{profile.firstName}</p>
                  <p className="text-xs text-muted">GPA {profile.gpa.toFixed(1)}</p>
                </div>
                <div className="relative">
                  <button
                    onClick={() => setProfileOpen(!profileOpen)}
                    className="w-10 h-10 rounded-full font-semibold text-white flex items-center justify-center transition-transform hover:scale-110"
                    style={{ background: 'linear-gradient(135deg, #6366f1, #ec4899)' }}
                  >
                    {profile.firstName[0]}{profile.lastName[0]}
                  </button>
                  {profileOpen && (
                    <div className="absolute top-12 right-0 bg-white border border-gray-200 rounded-lg shadow-lg min-w-max z-50">
                      <Link
                        href="/profile"
                        className="block px-4 py-2 text-sm text-charcoal hover:bg-gray-50 first:rounded-t-lg"
                        onClick={() => setProfileOpen(false)}
                      >
                        Edit Profile
                      </Link>
                      <button
                        onClick={() => {
                          // Clear localStorage to logout
                          localStorage.removeItem("studentProfile");
                          localStorage.removeItem("savedColleges");
                          window.location.href = "/";
                        }}
                        className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 last:rounded-b-lg"
                      >
                        Logout
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <Link href="/profile" className="btn-primary text-sm">
                Build Profile
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden p-2 rounded-md text-charcoal hover:bg-gray-100 transition"
            aria-label="Toggle menu"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d={mobileOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"}
              />
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="md:hidden border-t border-gray-200 bg-white">
            <div className="px-4 py-4 space-y-2">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className={`block px-4 py-2 rounded-lg text-sm font-medium transition ${
                    isActive(link.href)
                      ? 'bg-sage/10 text-sage'
                      : 'text-charcoal hover:bg-gray-100'
                  }`}
                >
                  {link.label}
                </Link>
              ))}

              {profile ? (
                <div className="border-t border-gray-200 pt-4 mt-4">
                  <div className="flex items-center gap-3 mb-4">
                    <div
                      className="w-10 h-10 rounded-full font-semibold text-white flex items-center justify-center"
                      style={{ background: 'linear-gradient(135deg, #6366f1, #ec4899)' }}
                    >
                      {profile.firstName[0]}{profile.lastName[0]}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-charcoal">{profile.firstName} {profile.lastName}</p>
                      <p className="text-xs text-muted">GPA {profile.gpa.toFixed(1)}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Link
                      href="/profile"
                      onClick={() => setMobileOpen(false)}
                      className="flex-1 px-4 py-2 text-sm text-center rounded-lg bg-gray-100 text-charcoal hover:bg-gray-200 transition"
                    >
                      Edit
                    </Link>
                    <button
                      onClick={() => {
                        localStorage.removeItem("studentProfile");
                        localStorage.removeItem("savedColleges");
                        window.location.href = "/";
                      }}
                      className="flex-1 px-4 py-2 text-sm text-center rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition"
                    >
                      Logout
                    </button>
                  </div>
                </div>
              ) : (
                <Link
                  href="/profile"
                  onClick={() => setMobileOpen(false)}
                  className="block px-4 py-2 text-center btn-primary text-sm mt-2"
                >
                  Build Profile
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}