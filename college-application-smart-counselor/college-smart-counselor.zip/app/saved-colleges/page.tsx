"use client";

import { useApp } from "@/lib/AppContext";
import Link from "next/link";
import { useState } from "react";

export default function SavedCollegesPage() {
  const { savedColleges, removeSavedCollege } = useApp();
  const [expandedId, setExpandedId] = useState<string | null>(null);

  if (savedColleges.length === 0) {
    return (
      <div className="text-center space-y-6 py-20">
        <div className="w-20 h-20 mx-auto rounded-full bg-sage/10 flex items-center justify-center text-4xl">
          📚
        </div>
        <h2 className="font-display text-3xl font-bold text-charcoal">No Colleges Saved Yet</h2>
        <p className="text-lg text-muted max-w-md mx-auto">Start saving colleges from the Colleges page to organize your application list.</p>
        <Link href="/colleges" className="btn-primary inline-block">
          Browse Colleges
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="font-display text-4xl font-bold text-charcoal">My Saved Colleges</h1>
        <p className="text-lg text-muted max-w-2xl mx-auto">
          You have saved {savedColleges.length} college{savedColleges.length !== 1 ? "s" : ""} to your list
        </p>
      </div>

      {/* Colleges Grid */}
      <div className="grid gap-6">
        {savedColleges.map((college) => (
          <div key={college.id} className="card p-6 space-y-4">
            {/* College Header */}
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="font-display text-2xl font-bold text-charcoal mb-1">{college.name}</h3>
                <p className="text-sm text-muted">{college.location}</p>
              </div>
              <button
                onClick={() => removeSavedCollege(college.id)}
                className="px-3 py-1 text-sm text-red-600 hover:bg-red-50 rounded-lg transition"
              >
                Remove
              </button>
            </div>

            {/* College Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-gray-200">
              <div>
                <p className="text-xs text-muted mb-1">Avg GPA</p>
                <p className="font-semibold text-charcoal">{college.avgGPA.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-xs text-muted mb-1">Avg SAT</p>
                <p className="font-semibold text-charcoal">{college.avgSAT}</p>
              </div>
              <div>
                <p className="text-xs text-muted mb-1">Acceptance Rate</p>
                <p className="font-semibold text-charcoal">{college.acceptanceRate.toFixed(1)}%</p>
              </div>
              <div>
                <p className="text-xs text-muted mb-1">Annual Cost</p>
                <p className="font-semibold text-charcoal">${(college.avgCost / 1000).toFixed(0)}k</p>
              </div>
            </div>

            {/* Majors */}
            {college.majors && college.majors.length > 0 && (
              <div className="pt-4 border-t border-gray-200">
                <p className="text-sm font-semibold text-charcoal mb-2">Popular Majors</p>
                <div className="flex flex-wrap gap-2">
                  {college.majors.slice(0, 5).map((major, idx) => (
                    <span key={idx} className="px-3 py-1 text-xs bg-gray-100 text-charcoal rounded-full">
                      {major}
                    </span>
                  ))}
                  {college.majors.length > 5 && (
                    <span className="px-3 py-1 text-xs text-muted">+{college.majors.length - 5} more</span>
                  )}
                </div>
              </div>
            )}

            {/* Essays - Expandable */}
            {college.essays && college.essays.length > 0 && (
              <div className="pt-4 border-t border-gray-200">
                <button
                  onClick={() => setExpandedId(expandedId === college.id ? null : college.id)}
                  className="flex items-center justify-between w-full text-sm font-semibold text-charcoal hover:text-sage transition"
                >
                  <span>📝 Essay Prompts ({college.essays.length})</span>
                  <svg
                    className={`w-5 h-5 transition-transform ${expandedId === college.id ? 'rotate-180' : ''}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                  </svg>
                </button>

                {expandedId === college.id && (
                  <div className="mt-4 space-y-4">
                    {college.essays.map((essay, idx) => (
                      <div key={idx} className="p-4 bg-gray-50 rounded-lg space-y-2">
                        <div className="flex items-start justify-between">
                          <p className="font-medium text-charcoal text-sm">{essay.question}</p>
                          {essay.required && (
                            <span className="text-xs font-semibold text-red-600 bg-red-50 px-2 py-1 rounded">
                              Required
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-muted">Word limit: {essay.wordLimit}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Deadline */}
            {college.deadline && (
              <div className="pt-4 border-t border-gray-200 flex items-center gap-2">
                <span className="text-lg">📅</span>
                <div>
                  <p className="text-xs text-muted">Application Deadline</p>
                  <p className="text-sm font-semibold text-charcoal">{college.deadline}</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
