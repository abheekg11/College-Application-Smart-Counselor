"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useApp } from "@/lib/AppContext";
import { StudentProfile } from "@/types/profile";

export default function ProfilePage() {
  const router = useRouter();
  const { profile, setProfile } = useApp();
  const [step, setStep] = useState(1);
  const totalSteps = 4;

  const [formData, setFormData] = useState<Partial<StudentProfile>>({
    firstName: "",
    lastName: "",
    gpa: 0,
    weightedGpa: 0,
    satScore: 0,
    intendedMajor: "",
    academicInterests: [],
    extracurriculars: [],
    locationPreference: "",
    maxCost: 50000,
    essays: [],
    careerGoals: "",
    ...profile,
  });

  const [currentExtracurricular, setCurrentExtracurricular] = useState({
    activity: "",
    role: "",
    years: 1,
    hoursPerWeek: 1,
    description: "",
  });

  // Keep string inputs for numeric fields so typing isn't forced to 0 mid-edit
  const [gpaInput, setGpaInput] = useState<string>(
    formData.gpa !== undefined && formData.gpa !== null ? String(formData.gpa) : ""
  );
  const [satInput, setSatInput] = useState<string>(
    formData.satScore !== undefined && formData.satScore !== null ? String(formData.satScore) : ""
  );
  const [weightedInput, setWeightedInput] = useState<string>(
    (formData as any).weightedGpa !== undefined && (formData as any).weightedGpa !== null ? String((formData as any).weightedGpa) : ""
  );

  // Sync when profile loads from context/localStorage
  useEffect(() => {
    if (profile) {
      setFormData((prev) => ({ ...prev, ...profile }));
      setGpaInput(profile.gpa !== undefined && profile.gpa !== null ? String(profile.gpa) : "");
      setSatInput(profile.satScore !== undefined && profile.satScore !== null ? String(profile.satScore) : "");
      setWeightedInput((profile as any).weightedGpa !== undefined && (profile as any).weightedGpa !== null ? String((profile as any).weightedGpa) : "");
    }
  }, [profile]);

  const updateField = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const addExtracurricular = () => {
    if (currentExtracurricular.activity && currentExtracurricular.role) {
      updateField("extracurriculars", [
        ...(formData.extracurriculars || []),
        currentExtracurricular,
      ]);
      setCurrentExtracurricular({
        activity: "",
        role: "",
        years: 1,
        hoursPerWeek: 1,
        description: "",
      });
    }
  };

  const removeExtracurricular = (index: number) => {
    const updated = formData.extracurriculars?.filter((_, i) => i !== index) || [];
    updateField("extracurriculars", updated);
  };

  const saveProfile = () => {
    // Ensure numeric fields are parsed from the input strings before saving
    const finalProfile: StudentProfile = {
      ...(formData as StudentProfile),
      gpa: parseFloat(gpaInput) || 0,
      satScore: parseInt(satInput) || 0,
      weightedGpa: parseFloat(weightedInput) || 0,
    };

    setProfile(finalProfile);
    router.push("/dashboard");
  };

  const nextStep = () => {
    if (step < totalSteps) setStep(step + 1);
  };

  const prevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  const progress = (step / totalSteps) * 100;

  return (
    <div className="max-w-3xl mx-auto">
      <div className="text-center space-y-4 mb-8">
        <h1 className="font-display text-3xl font-bold text-charcoal">Build Your Profile</h1>
        <p className="text-sm text-muted">Help us understand you better to find your perfect college matches</p>

        <div className="max-w-md mx-auto pt-4">
          <div className="flex justify-between text-sm text-muted mb-2">
            <span>Step {step} of {totalSteps}</span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${progress}%` }} />
          </div>
        </div>
      </div>

      <div className="card p-6 md:p-8 space-y-6">
        {step === 1 && (
          <div className="space-y-6 animate-fade-in-up">
            <h2 className="font-display text-3xl font-bold text-charcoal">
              Personal Information
            </h2>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label>First Name</label>
                <input
                  type="text"
                  value={formData.firstName}
                  onChange={(e) => updateField("firstName", e.target.value)}
                  placeholder="John"
                />
              </div>

              <div>
                <label>Last Name</label>
                <input
                  type="text"
                  value={formData.lastName}
                  onChange={(e) => updateField("lastName", e.target.value)}
                  placeholder="Doe"
                />
              </div>
            </div>

            <div>
              <label>Career Goals</label>
              <textarea value={formData.careerGoals} onChange={(e) => updateField("careerGoals", e.target.value)} placeholder="Describe your career aspirations..." rows={4} />
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <h2 className="font-display text-2xl font-bold text-charcoal">Academic Profile</h2>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label>Unweighted GPA</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="4.0"
                  value={gpaInput}
                  onChange={(e) => setGpaInput(e.target.value)}
                  onBlur={() => updateField("gpa", parseFloat(gpaInput) || 0)}
                  placeholder="3.8"
                />
                <p className="text-sm text-muted mt-1">Out of 4.0 scale</p>

                <div className="mt-3">
                  <label>Weighted GPA</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="5.0"
                    value={weightedInput}
                    onChange={(e) => setWeightedInput(e.target.value)}
                    onBlur={() => updateField("weightedGpa", parseFloat(weightedInput) || 0)}
                    placeholder="4.2"
                  />
                  <p className="text-sm text-muted mt-1">Out of 5.0 scale (weighted)</p>
                </div>
              </div>

              <div>
                <label>SAT Score</label>
                <input
                  type="number"
                  min="400"
                  max="1600"
                  value={satInput}
                  onChange={(e) => setSatInput(e.target.value)}
                  onBlur={() => updateField("satScore", parseInt(satInput) || 0)}
                  placeholder="1400"
                />
                <p className="text-sm text-muted mt-1">Out of 1600</p>
              </div>
            </div>

            <div>
              <label>Intended Major</label>
              <select value={formData.intendedMajor} onChange={(e) => updateField("intendedMajor", e.target.value)}>
                <option value="">Select a major</option>
                <option value="Computer Science">Computer Science</option>
                <option value="Engineering">Engineering</option>
                <option value="Business">Business</option>
                <option value="Biology">Biology</option>
                <option value="Psychology">Psychology</option>
                <option value="Economics">Economics</option>
                <option value="Mathematics">Mathematics</option>
                <option value="Physics">Physics</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Political Science">Political Science</option>
                <option value="Communications">Communications</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label>Academic Interests (separate with commas)</label>
              <input type="text" value={formData.academicInterests?.join(", ") || ""} onChange={(e) => updateField("academicInterests", e.target.value.split(",").map((s) => s.trim()).filter(Boolean))} placeholder="Artificial Intelligence, Robotics, Data Science" />
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6">
            <h2 className="font-display text-2xl font-bold text-charcoal">Extracurricular Activities</h2>

            {/* Existing Extracurriculars */}
            {formData.extracurriculars && formData.extracurriculars.length > 0 && (
              <div className="space-y-3">
                {formData.extracurriculars.map((ec, index) => (
                  <div
                    key={index}
                    className="p-4 rounded-lg bg-gray-50 border border-gray-200 flex justify-between items-start"
                  >
                    <div>
                      <h4 className="font-semibold text-charcoal">{ec.activity}</h4>
                      <p className="text-sm text-slate-600">{ec.role}</p>
                      <p className="text-sm text-slate-500">
                        {ec.years} year{ec.years > 1 ? "s" : ""} • {ec.hoursPerWeek} hrs/week
                      </p>
                      {ec.description && (
                        <p className="text-sm text-slate-600 mt-1">{ec.description}</p>
                      )}
                    </div>
                    <button
                      onClick={() => removeExtracurricular(index)}
                      className="text-red-500 hover:text-red-700 text-sm font-medium"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Add New Extracurricular */}
            <div className="p-4 rounded-lg bg-gray-50 border-2 border-dashed border-gray-200 space-y-4">
              <h3 className="font-semibold text-charcoal">Add Activity</h3>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label>Activity Name</label>
                  <input
                    type="text"
                    value={currentExtracurricular.activity}
                    onChange={(e) =>
                      setCurrentExtracurricular({
                        ...currentExtracurricular,
                        activity: e.target.value,
                      })
                    }
                    placeholder="Debate Club"
                  />
                </div>

                <div>
                  <label>Your Role</label>
                  <input
                    type="text"
                    value={currentExtracurricular.role}
                    onChange={(e) =>
                      setCurrentExtracurricular({
                        ...currentExtracurricular,
                        role: e.target.value,
                      })
                    }
                    placeholder="President"
                  />
                </div>

                <div>
                  <label>Years Involved</label>
                  <input
                    type="number"
                    min="1"
                    max="4"
                    value={currentExtracurricular.years}
                    onChange={(e) =>
                      setCurrentExtracurricular({
                        ...currentExtracurricular,
                        years: parseInt(e.target.value) || 1,
                      })
                    }
                  />
                </div>

                <div>
                  <label>Hours per Week</label>
                  <input
                    type="number"
                    min="1"
                    max="40"
                    value={currentExtracurricular.hoursPerWeek}
                    onChange={(e) =>
                      setCurrentExtracurricular({
                        ...currentExtracurricular,
                        hoursPerWeek: parseInt(e.target.value) || 1,
                      })
                    }
                  />
                </div>
              </div>

              <div>
                <label>Description</label>
                <textarea
                  value={currentExtracurricular.description}
                  onChange={(e) =>
                    setCurrentExtracurricular({
                      ...currentExtracurricular,
                      description: e.target.value,
                    })
                  }
                  placeholder="Describe your involvement and achievements..."
                  rows={3}
                />
              </div>

              <button onClick={addExtracurricular} className="btn-ghost w-full" disabled={!currentExtracurricular.activity || !currentExtracurricular.role}>Add Activity</button>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-6">
            <h2 className="font-display text-2xl font-bold text-charcoal">College Preferences</h2>

            <div>
              <label>Location Preference</label>
              <select
                value={formData.locationPreference}
                onChange={(e) => updateField("locationPreference", e.target.value)}
              >
                <option value="">Any location</option>
                <option value="Northern California">Northern California</option>
                <option value="Southern California">Southern California</option>
                <option value="Los Angeles">Los Angeles Area</option>
                <option value="San Francisco">San Francisco Bay Area</option>
                <option value="San Diego">San Diego Area</option>
              </select>
            </div>

            <div>
              <label>Maximum Annual Cost</label>
              <input type="number" min="0" step="1000" value={formData.maxCost} onChange={(e) => updateField("maxCost", parseInt(e.target.value) || 0)} />
              <p className="text-sm text-muted mt-1">Including tuition, fees, and living expenses</p>
            </div>

            <div>
              <label>School Size Preference</label>
              <select
                value={formData.schoolSize || ""}
                onChange={(e) =>
                  updateField("schoolSize", e.target.value || undefined)
                }
              >
                <option value="">No preference</option>
                <option value="small">Small (&lt;5,000 students)</option>
                <option value="medium">Medium (5,000-15,000 students)</option>
                <option value="large">Large (&gt;15,000 students)</option>
              </select>
            </div>

            <div>
              <label>Campus Setting</label>
              <select
                value={formData.settingPreference || ""}
                onChange={(e) =>
                  updateField("settingPreference", e.target.value || undefined)
                }
              >
                <option value="">No preference</option>
                <option value="urban">Urban</option>
                <option value="suburban">Suburban</option>
                <option value="rural">Rural</option>
              </select>
            </div>
          </div>
        )}

        <div className="flex justify-between pt-4">
          <button onClick={prevStep} disabled={step === 1} className="px-4 py-2 rounded-full border">Previous</button>
          {step < totalSteps ? (
            <button onClick={nextStep} className="btn-primary">Next Step</button>
          ) : (
            <button onClick={saveProfile} className="btn-primary">Save & View Dashboard</button>
          )}
        </div>
      </div>
    </div>
  );
}