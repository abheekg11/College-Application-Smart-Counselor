"use client"

export default function ProjectPage() {
  return (
    <div className="max-w-4xl mx-auto py-16">
      <header className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-charcoal gradient-text decorative-line">
          College Application Planning Smart Counselor for High School Seniors
        </h1>
        <p className="mt-4 text-slate-600 max-w-2xl mx-auto">
          A concise project description and design document for the CollegePath prototype.
        </p>
      </header>

      <article className="prose prose-slate mx-auto">
        <section>
          <h2>1. Project Title</h2>
          <p>
            College Application Planning Smart Counselor for High School Seniors
          </p>
        </section>

        <section>
          <h2>1.2 Problem Statement</h2>
          <p>
            High school seniors often struggle to maintain a schedule for their college
            applications, causing them to regularly fall behind and compromise their
            future careers. Moreover, they must spend excessive time researching
            college prospects, majors, costs, locations, and application requirements.
            This inefficiency reduces time available for writing essays and coursework,
            and makes it difficult to organize previous applications or essays across
            multiple colleges. The resulting stress can negatively impact application
            quality and academic performance.
          </p>
        </section>

        <section>
          <h2>1.3 Target Users</h2>
          <p>
            High school seniors beginning college applications. Users will enter GPA,
            coursework, and extracurriculars. The system will recommend colleges
            classified as safety, target, and reach; allow adding colleges to a
            personal list; and show college-specific essays and deadlines.
          </p>
        </section>

        <section>
          <h2>2. System Concept</h2>
          <h3>2.1 High-Level System Description</h3>
          <p>
            The system is a personal, context-aware recommendation engine that acts
            like a counselor for high school students. It combines user preferences,
            academic factors (grades, extracurriculars), and goals to recommend
            colleges and help organize application tasks. It also tracks deadlines and
            essay prompts, providing reminders and organization to reduce stress and
            help students allocate time effectively.
          </p>

          <h3>2.2 User Need → System Response</h3>
          <p>
            When a student updates academic information or preferences, the system
            re-evaluates the profile and updates recommendations. Colleges are
            categorized into safety, target, and reach, and application requirements
            and essay prompts are surfaced. The system proactively notifies students
            about upcoming deadlines and incomplete tasks.
          </p>
        </section>

        <section>
          <h2>3. Data and Information Sources</h2>
          <h3>3.1 Data Sources</h3>
          <p>
            College websites (admissions pages and essay prompts), developer-provided
            college datasets (sample of ~20–30 colleges), and user-provided profile
            data (GPA, courses, extracurriculars, preferences). Additional factors
            include residency status (in-state/out-of-state), major interests, and
            rankings or cost metadata.
          </p>

          <h3>3.2 Data Collection Strategy</h3>
          <p>
            Student data is entered manually at signup. College data will be initially
            filled by developers and optionally updated via scraping or public APIs.
            Essays written by students are stored in the app. Some data (rankings,
            costs) may be periodically refreshed rather than pulled in real time.
          </p>
        </section>

        <section>
          <h2>4. Personal Model and Context</h2>
          <h3>4.1 Personal Model</h3>
          <p>
            The model captures academic metrics, extracurriculars, and preferences.
            Recommendations emphasize alignment between student strengths and college
            profiles; essay suggestion tools extract themes from past essays and map
            them to prompts. The system builds a time-based schedule from deadlines
            and suggests priorities based on remaining time.
          </p>

          <h3>4.2 Contextual Factors</h3>
          <p>
            The system adapts schedules based on when the student logs in, the
            proximity of deadlines, and the student's chosen priorities. College
            rankings and program fit influence recommendations and prioritization.
          </p>
        </section>

        <section>
          <h2>5. Search / Recommendation Logic</h2>
          <h3>5.1 Search or Recommendation Task</h3>
          <p>
            The system ranks colleges (top 10 highlighted) based on fit with the
            student's profile, preferences, and admission likelihood. Students can
            filter by location, cost, and major. Essay suggestions highlight themes
            drawn from previous writing matched to prompt topics.
          </p>

          <h3>5.2 Matching and Ranking (Conceptual)</h3>
          <p>
            Options rank higher when they better align with student preferences and
            increase admission likelihood given academic metrics. Safety schools are
            chosen to maximize admission probability; reach and target schools favor
            alignment with goals and program fit. Essay suggestions match prompt
            themes to the student's past essay content.
          </p>
        </section>

        <section>
          <h2>6. System Architecture (Conceptual)</h2>
          <h3>6.1 Major Components</h3>
          <ul>
            <li>User Profile (GPA, scores, classes, extracurriculars, preferences)</li>
            <li>College Information Database (admissions stats, essays, deadlines)</li>
            <li>Personal Model Engine (profiles & scoring)</li>
            <li>Recommendation Engine (rank & categorize colleges)</li>
            <li>Essay Suggestion Engine (theme matching from past essays)</li>
            <li>Application Tracker & Scheduler (deadlines, reminders)</li>
            <li>User Dashboard (recommendations, tasks, timeline)</li>
          </ul>

          <h3>6.2 User Interface and Presentation</h3>
          <p>
            Recommendations appear in a dashboard with top 10 colleges split into
            safety/target/reach, each showing alignment score, admission probability,
            and cost. College cards show deadlines and essay prompts. A timeline
            provides personalized schedules and task checkpoints.
          </p>
        </section>

        <section>
          <h2>7. Project Scope and Feasibility</h2>
          <h3>7.1 What Will Be Implemented</h3>
          <p>
            A functional prototype implementing a scoring-based matching algorithm
            comparing student profiles to college data. It will rank and categorize
            schools, provide filtering, and offer basic essay prompt matching using
            keyword-based suggestions drawn from the student's previous essays.
          </p>

          <h3>7.2 What Is Out of Scope</h3>
          <p>
            Real-time scraping of college websites, direct Common App integration,
            automated essay generation, financial aid calculators, and direct
            communication with admissions offices are out of scope for this quarter.
          </p>
        </section>
      </article>
    </div>
  )
}
