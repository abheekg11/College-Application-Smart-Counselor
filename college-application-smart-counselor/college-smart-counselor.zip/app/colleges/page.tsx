"use client";

import { useState, useEffect } from "react";
import { useApp } from "@/lib/AppContext";
import { useSearchParams } from "next/navigation";
import { colleges as allColleges } from "@/lib/collegeData";
import { recommendColleges } from "@/lib/scoring";
import { College } from "@/types/college";
import CollegeCard from "@/components/CollegeCard";
import Link from "next/link";

export default function CollegesPage() {
  const { profile, savedColleges, addSavedCollege, removeSavedCollege } = useApp();
  const searchParams = useSearchParams();
  const searchQuery = searchParams.get("search") || "";
  
  const [colleges, setColleges] = useState<College[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<"all" | "Safety" | "Target" | "Reach">("all");
  const [sortBy, setSortBy] = useState<"alignment" | "probability" | "cost">("alignment");
  const [selectedCollege, setSelectedCollege] = useState<College | null>(null);

  useEffect(() => {
    let collegeList = allColleges;
    
    // Apply search filter if search query exists
    if (searchQuery.trim()) {
      collegeList = allColleges.filter(c =>
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (c.majors && c.majors.some(m => m.toLowerCase().includes(searchQuery.toLowerCase())))
      );
    }

    // Apply profile-based recommendations if profile exists
    if (profile) {
      const recommended = recommendColleges(collegeList, profile);
      setColleges(recommended);
    } else {
      setColleges(collegeList);
    }
  }, [profile, searchQuery]);

  const filteredColleges = colleges.filter((college) =>
    selectedCategory === "all" ? true : college.category === selectedCategory
  );

  const sortedColleges = [...filteredColleges].sort((a, b) => {
    if (sortBy === "alignment") {
      return (b.alignmentScore || 0) - (a.alignmentScore || 0);
    } else if (sortBy === "probability") {
      return (b.admissionProbability || 0) - (a.admissionProbability || 0);
    } else {
      return a.avgCost - b.avgCost;
    }
  });

  const stats = {
    safety: colleges.filter((c) => c.category === "Safety").length,
    target: colleges.filter((c) => c.category === "Target").length,
    reach: colleges.filter((c) => c.category === "Reach").length,
  };

  if (!profile) {
    return (
      <div className="text-center space-y-6 py-20">
        <div className="w-20 h-20 mx-auto rounded-full bg-sage/10 flex items-center justify-center text-4xl">
          📝
        </div>
        <h2 className="font-display text-3xl font-bold text-charcoal">Create Your Profile First</h2>
        <p className="text-lg text-muted max-w-md mx-auto">To get personalized college recommendations, please complete your profile.</p>
        <Link href="/profile" className="btn-primary inline-block">Build Your Profile</Link>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="font-display text-4xl font-bold text-charcoal">Your College Matches</h1>
        <p className="text-lg text-muted max-w-2xl mx-auto">Based on your profile, we've categorized {colleges.length} colleges into safety, target, and reach schools.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="card p-6 text-center">
          <div className="text-3xl font-display font-bold text-sage mb-2">{stats.safety}</div>
          <div className="text-muted">Safety Schools</div>
          <div className="text-xs text-muted mt-1">70%+ admission chance</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-display font-bold text-charcoal mb-2">{stats.target}</div>
          <div className="text-muted">Target Schools</div>
          <div className="text-xs text-muted mt-1">40-70% admission chance</div>
        </div>
        <div className="card p-6 text-center">
          <div className="text-3xl font-display font-bold text-terracotta mb-2">{stats.reach}</div>
          <div className="text-muted">Reach Schools</div>
          <div className="text-xs text-muted mt-1">&lt;40% admission chance</div>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4">
        <div className="flex flex-wrap gap-4 items-center justify-between">
          {/* Category Filter */}
          <div className="flex gap-2">
            <button onClick={() => setSelectedCategory("all")} className={`px-4 py-2 rounded-full font-medium transition ${selectedCategory === "all" ? 'bg-sage text-white' : 'bg-gray-100 text-muted hover:bg-gray-50'}`}>
              All ({colleges.length})
            </button>
            <button onClick={() => setSelectedCategory("Safety")} className={`px-4 py-2 rounded-full font-medium transition ${selectedCategory === 'Safety' ? 'bg-sage text-white' : 'bg-gray-100 text-muted hover:bg-gray-50'}`}>Safety ({stats.safety})</button>
            <button onClick={() => setSelectedCategory("Target")} className={`px-4 py-2 rounded-full font-medium transition ${selectedCategory === 'Target' ? 'bg-charcoal text-white' : 'bg-gray-100 text-muted hover:bg-gray-50'}`}>Target ({stats.target})</button>
            <button onClick={() => setSelectedCategory("Reach")} className={`px-4 py-2 rounded-full font-medium transition ${selectedCategory === 'Reach' ? 'bg-terracotta text-white' : 'bg-gray-100 text-muted hover:bg-gray-50'}`}>Reach ({stats.reach})</button>
          </div>

          {/* Sort By */}
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium text-muted">Sort by:</label>
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value as any)} className="px-3 py-2 rounded-lg border">
              <option value="alignment">Best Match</option>
              <option value="probability">Admission Chance</option>
              <option value="cost">Lowest Cost</option>
            </select>
          </div>
        </div>
      </div>

      {/* College Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sortedColleges.map((college) => (
          <CollegeCard
            key={college.id}
            college={college}
            onClick={() => setSelectedCollege(college)}
          />
        ))}
      </div>

      {/* College Detail Modal */}
      {selectedCollege && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
          onClick={() => setSelectedCollege(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-8"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="font-display text-3xl font-bold text-charcoal mb-2">
                  {selectedCollege.name}
                </h2>
                <p className="text-slate-600">{selectedCollege.location}</p>
              </div>
              <button
                onClick={() => setSelectedCollege(null)}
                className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-slate-500 mb-1">Acceptance Rate</p>
                <p className="text-2xl font-bold text-charcoal">
                  {selectedCollege.acceptanceRate.toFixed(1)}%
                </p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-slate-500 mb-1">Avg GPA</p>
                <p className="text-2xl font-bold text-charcoal">
                  {selectedCollege.avgGPA.toFixed(2)}
                </p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-slate-500 mb-1">Avg SAT</p>
                <p className="text-2xl font-bold text-charcoal">
                  {selectedCollege.avgSAT}
                </p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-slate-500 mb-1">Annual Cost</p>
                <p className="text-2xl font-bold text-charcoal">
                  ${(selectedCollege.avgCost / 1000).toFixed(0)}k
                </p>
              </div>
            </div>

            {/* Match Scores */}
            {selectedCollege.admissionProbability !== undefined && (
              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <div className="bg-sage/10 border border-sage/20 rounded-lg p-4">
                  <p className="text-sm text-sage font-medium mb-2">Your Admission Chance</p>
                  <div className="flex items-end gap-2">
                    <span className="text-3xl font-bold text-sage">
                      {selectedCollege.admissionProbability.toFixed(0)}%
                    </span>
                    <span className="text-sm text-slate-600 mb-1">
                      ({selectedCollege.category})
                    </span>
                  </div>
                </div>
                {selectedCollege.alignmentScore !== undefined && (
                  <div className="bg-terracotta/10 border border-terracotta/20 rounded-lg p-4">
                    <p className="text-sm text-terracotta font-medium mb-2">Match Score</p>
                    <div className="flex items-end gap-2">
                      <span className="text-3xl font-bold text-terracotta">
                        {selectedCollege.alignmentScore.toFixed(0)}%
                      </span>
                      <span className="text-sm text-slate-600 mb-1">fit</span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Majors */}
            <div className="mb-6">
              <h3 className="font-semibold text-charcoal mb-3">Available Majors</h3>
              <div className="flex flex-wrap gap-2">
                {selectedCollege.majors.map((major, idx) => (
                  <span
                    key={idx}
                    className={`px-3 py-1.5 rounded-full text-sm ${
                      profile.intendedMajor === major
                        ? "bg-sage text-white"
                        : "bg-gray-100 text-gray-700"
                    }`}
                  >
                    {major}
                    {profile.intendedMajor === major && " ✓"}
                  </span>
                ))}
              </div>
            </div>

            {/* Essay Prompts */}
            <div className="mb-6">
              <h3 className="font-semibold text-charcoal mb-3">Essay Prompts</h3>
              <div className="space-y-3">
                {selectedCollege.essays.map((essay, idx) => (
                  <div key={idx} className="bg-gray-50 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-2">
                      <p className="text-sm font-medium text-charcoal">{essay.question}</p>
                      {essay.required && (
                        <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded">
                          Required
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-slate-500">
                      Max {essay.wordLimit} words
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Deadline */}
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
              <div className="flex items-center gap-2">
                <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div>
                  <p className="text-sm font-medium text-yellow-900">Application Deadline</p>
                  <p className="text-sm text-yellow-700">{selectedCollege.deadline}</p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={() => {
                  if (savedColleges.some(c => c.id === selectedCollege.id)) {
                    removeSavedCollege(selectedCollege.id);
                  } else {
                    addSavedCollege(selectedCollege);
                  }
                }}
                className="flex-1 btn-primary"
              >
                {savedColleges.some(c => c.id === selectedCollege.id) ? "Remove from List" : "Add to My List"}
              </button>
              <button
                onClick={() => setSelectedCollege(null)}
                className="flex-1 btn-secondary"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}