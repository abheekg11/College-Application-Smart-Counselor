"use client";

import { useApp } from "@/lib/AppContext";
import { useRouter } from "next/navigation";
import Link from "next/link";
import CollegeCard from "@/components/CollegeCard";
import { colleges as allColleges } from "@/lib/collegeData";
import { recommendColleges } from "@/lib/scoring";
import { useEffect, useState } from "react";
import { College } from "@/types/college";

export default function DashboardPage() {
  const { profile, savedColleges } = useApp();
  const router = useRouter();
  const [topColleges, setTopColleges] = useState<College[]>([]);

  useEffect(() => {
    if (profile) {
      const recommended = recommendColleges(allColleges, profile);
      const sorted = [...recommended].sort((a, b) => 
        (b.alignmentScore || 0) - (a.alignmentScore || 0)
      );
      setTopColleges(sorted.slice(0, 6));
    }
  }, [profile]);

  if (!profile) {
    return (
      <div className="text-center space-y-6 py-20">
        <div className="w-20 h-20 mx-auto rounded-full bg-sage/10 flex items-center justify-center text-4xl">👋</div>
        <h2 className="font-display text-3xl font-bold text-charcoal">Welcome to CollegePath</h2>
        <p className="text-lg text-muted max-w-md mx-auto">Let's get started by creating your profile. This will help us recommend the best colleges for you.</p>
        <Link href="/profile" className="btn-primary inline-block">Create Your Profile</Link>
      </div>
    );
  }

  const upcomingDeadlines = savedColleges
    .map(college => ({
      college: college.name,
      deadline: college.deadline,
      date: new Date(college.deadline)
    }))
    .sort((a, b) => a.date.getTime() - b.date.getTime())
    .slice(0, 5);

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="card p-6">
        <h1 className="font-display text-2xl font-bold text-charcoal">Welcome back, {profile.firstName}!</h1>
        <p className="text-sm text-muted">Here's your college application overview</p>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <div className="card p-4 text-center">
          <div className="text-3xl font-bold text-charcoal mb-1">{savedColleges.length}</div>
          <div className="text-sm text-muted">Colleges Saved</div>
        </div>

        <div className="card p-4 text-center">
          <div className="text-3xl font-bold text-charcoal mb-1">{profile.gpa.toFixed(2)}</div>
          <div className="text-sm text-muted">Your GPA</div>
        </div>

        <div className="card p-4 text-center">
          <div className="text-3xl font-bold text-charcoal mb-1">{savedColleges.reduce((acc, c) => acc + c.essays.length, 0)}</div>
          <div className="text-sm text-muted">Essays to Write</div>
        </div>

        <div className="card p-4 text-center">
          <div className="text-3xl font-bold text-charcoal mb-1">{profile.extracurriculars?.length || 0}</div>
          <div className="text-sm text-muted">Extracurriculars</div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="font-display text-xl font-bold text-charcoal">Top Matches for You</h2>
            <Link href="/colleges" className="text-muted font-medium text-sm">View All →</Link>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {topColleges.map((college) => (
              <CollegeCard key={college.id} college={college} />
            ))}
          </div>

          {topColleges.length === 0 && (
            <div className="text-center py-12 card">
              <p className="text-muted">Complete your profile to see personalized recommendations</p>
              <Link href="/profile" className="btn-primary inline-block mt-4">Complete Profile</Link>
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="card p-4">
            <h3 className="font-semibold text-charcoal mb-3">Upcoming Deadlines</h3>
            {upcomingDeadlines.length > 0 ? (
              <div className="space-y-3">
                {upcomingDeadlines.map((item, idx) => (
                  <div key={idx} className="flex justify-between items-start p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <p className="font-medium text-sm text-charcoal">{item.college}</p>
                      <p className="text-xs text-muted mt-1">{item.deadline}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted text-sm">
                <p>No deadlines yet</p>
                <Link href="/colleges" className="text-sage font-medium mt-2 inline-block">Add colleges to track deadlines</Link>
              </div>
            )}
          </div>

          <div className="card p-4">
            <h3 className="font-semibold text-charcoal mb-3">Quick Actions</h3>
            <div className="space-y-3">
              <Link href="/profile" className="block p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-sage/10 flex items-center justify-center">👤</div>
                  <div>
                    <p className="font-medium text-charcoal text-sm">Update Profile</p>
                    <p className="text-xs text-muted">Edit your information</p>
                  </div>
                </div>
              </Link>

              <Link href="/colleges" className="block p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-terracotta/10 flex items-center justify-center">🎓</div>
                  <div>
                    <p className="font-medium text-charcoal text-sm">Explore Colleges</p>
                    <p className="text-xs text-muted">Find your matches</p>
                  </div>
                </div>
              </Link>

              <Link href="/tracker" className="block p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center">📋</div>
                  <div>
                    <p className="font-medium text-charcoal text-sm">Application Tracker</p>
                    <p className="text-xs text-muted">Manage your apps</p>
                  </div>
                </div>
              </Link>
            </div>
          </div>

          <div className="card p-4">
            <h3 className="font-semibold text-charcoal mb-3">Your Profile</h3>
            <div className="space-y-3 text-sm text-muted">
              <div className="flex justify-between"><span>Major:</span><span className="font-medium text-charcoal">{profile.intendedMajor || "Not set"}</span></div>
              <div className="flex justify-between"><span>GPA:</span><span className="font-medium text-charcoal">{profile.gpa.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>SAT:</span><span className="font-medium text-charcoal">{profile.satScore}</span></div>
              <div className="flex justify-between"><span>Location:</span><span className="font-medium text-charcoal">{profile.locationPreference || "Any"}</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}