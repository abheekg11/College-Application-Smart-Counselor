"use client";

import Link from "next/link";
import { useApp } from "@/lib/AppContext";
import { useEffect, useState } from "react";
import { colleges as allColleges } from "@/lib/collegeData";
import { recommendColleges } from "@/lib/scoring";
import CollegeCard from "@/components/CollegeCard";
import { College } from "@/types/college";

export default function HomePage() {
  const { profile } = useApp();
  const [topMatches, setTopMatches] = useState<College[]>([]);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (profile) {
      const rec = recommendColleges(allColleges, profile).slice(0, 6);
      setTopMatches(rec);
    } else {
      setTopMatches(allColleges.slice(0, 6));
    }
  }, [profile]);

  const handleSearch = () => {
    if (searchQuery.trim()) {
      const filtered = allColleges.filter(c => 
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (c.majors && c.majors.some(m => m.toLowerCase().includes(searchQuery.toLowerCase())))
      );
      if (filtered.length > 0) {
        window.location.href = `/colleges?search=${encodeURIComponent(searchQuery)}`;
      } else {
        alert("No colleges found matching your search. Try browsing all colleges.");
      }
    }
  };

  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  return (
    <div className="">
      {/* HERO: compact, high-signal */}
      <section className="bg-white">
        <div className="container py-12 lg:py-20">
          <div className="flex flex-col lg:flex-row items-center gap-8">
            <div className="lg:w-2/3">
              <h1 className="text-3xl md:text-4xl font-display font-bold text-charcoal leading-tight mb-4">
                Plan, Match, and Apply — All in One Place
              </h1>
              <p className="text-base text-muted max-w-2xl mb-6">
                CollegePath helps high school seniors find the right colleges, organize
                applications, and manage essays and deadlines — saving time so students
                can focus on what matters.
              </p>

              <div className="flex flex-wrap gap-3 items-center">
                <Link href="/profile" className="btn-primary">Get Started — It's Free</Link>
                <Link href="/colleges" className="btn-ghost">Browse Colleges</Link>
                <span className="text-sm text-muted ml-2">No credit card required</span>
              </div>

              {/* Search / Quick start */}
              <div className="mt-8">
                <div className="flex items-center gap-3">
                  <input
                    aria-label="Search colleges"
                    placeholder="Search colleges, majors, or locations"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={handleSearchKeyDown}
                    className="flex-1 px-4 py-3 rounded-lg border border-gray-300 focus:border-sage focus:outline-none"
                  />
                  <button onClick={handleSearch} className="btn-primary">Search</button>
                </div>
                <div className="mt-3 text-xs text-muted">Tip: try "Computer Science" or "UC Berkeley"</div>
              </div>
            </div>

            <div className="lg:w-1/3">
            <div className="card p-6">
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-muted">Personalized Match</div>
                  <div className="text-xl font-semibold text-charcoal">Top colleges tailored to you</div>
                </div>
                <p className="text-sm text-muted">Complete your profile to unlock detailed recommendations and application timelines.</p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-gray-50 rounded-lg text-center">
                    <div className="text-sm text-muted">Average Match</div>
                    <div className="text-lg font-bold text-sage">72%</div>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-lg text-center">
                    <div className="text-sm text-muted">Deadlines Tracked</div>
                    <div className="text-lg font-bold text-charcoal">15</div>
                  </div>
                </div>
              </div>
            </div>
            </div>
          </div>

          {/* Trust / logos bar */}
          <div className="mt-10 pt-8 border-t border-gray-200">
            <div className="text-xs text-muted uppercase font-semibold mb-4">Trusted by</div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-8">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded bg-sage/10 flex items-center justify-center text-sm font-bold text-sage">🎓</div>
                <span className="text-sm font-medium text-charcoal">High School Counselors</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded bg-terracotta/10 flex items-center justify-center text-sm font-bold text-terracotta">🤝</div>
                <span className="text-sm font-medium text-charcoal">College Clubs</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded bg-sage/10 flex items-center justify-center text-sm font-bold text-sage">⭐</div>
                <span className="text-sm font-medium text-charcoal">Student Ambassadors</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="py-12">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="card p-6">
              <div className="text-2xl mb-3">🎯</div>
              <h3 className="font-semibold text-charcoal mb-2">Smart Matching</h3>
              <p className="text-sm text-muted">Profiles are scored against college admissions profiles and ranked by fit.</p>
            </div>

            <div className="card p-6">
              <div className="text-2xl mb-3">🗓️</div>
              <h3 className="font-semibold text-charcoal mb-2">Deadline Planner</h3>
              <p className="text-sm text-muted">Generate personalized timelines and reminders for each application.</p>
            </div>

            <div className="card p-6">
              <div className="text-2xl mb-3">📝</div>
              <h3 className="font-semibold text-charcoal mb-2">Essay Organizer</h3>
              <p className="text-sm text-muted">Store, reuse, and map essay content to college prompts quickly.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Top Matches preview */}
      <section className="py-8 bg-gray-50">
        <div className="container">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-charcoal">Top matches for you</h2>
            <Link href="/colleges" className="text-sm text-muted">View all colleges →</Link>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {topMatches.slice(0, 3).map((c) => (
              <CollegeCard key={c.id} college={c} />
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-12 bg-white">
        <div className="container max-w-4xl">
          <div className="card p-8 text-center">
            <h3 className="text-xl font-semibold text-charcoal mb-3">Ready to get organized?</h3>
            <p className="text-sm text-muted mb-6">Create your profile and receive a tailored college plan in minutes.</p>
            <Link href="/profile" className="btn-primary">Create My Profile</Link>
          </div>
        </div>
      </section>
    </div>
  );
}